This is **NOT** an open source project, please check the licence file. 

If you would like to contribute please contact Earendel on Discord first: https://discord.gg/ymjUVMv

If you are a mod maker and are trying to control compatability with Space Exploration, require the main Space Exploration mod, not this mod. 

Do not add this postprocess mod as a dependency of you mod or your mod will be marked as incompatible with Space Exploration. 

The post process mod should always run last in mod load order. 

Most of the code in the postprocess mod is compatability code. If any of the code is causing compatibility problems, contact me on my discord https://discord.gg/ymjUVMv and I will update the code.
