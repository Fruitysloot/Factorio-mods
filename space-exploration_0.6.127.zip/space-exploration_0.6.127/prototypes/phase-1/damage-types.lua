data:extend({
  {
    type = "damage-type",
    name = "cold",
  },
  {
    type = "damage-type",
    name = "suffocation",
  },
  {
    type = "damage-type",
    name = "meteor",
  },

  {
    type = "trigger-target-type",
    name = "flammable"
  },
  {
    type = "trigger-target-type",
    name = "tree"
  }
})
