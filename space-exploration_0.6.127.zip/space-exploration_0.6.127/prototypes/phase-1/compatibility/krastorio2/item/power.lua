
data.raw.item["charged-antimatter-fuel-cell"].fuel_value = "100GJ" --same as antimatter cell