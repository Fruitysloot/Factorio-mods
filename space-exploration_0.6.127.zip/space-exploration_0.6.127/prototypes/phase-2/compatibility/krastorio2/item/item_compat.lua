
local path = "prototypes/phase-2/compatibility/krastorio2/item/"

require(path .. "item_ordering")

require(path .. "science")
require(path .. "equipment")