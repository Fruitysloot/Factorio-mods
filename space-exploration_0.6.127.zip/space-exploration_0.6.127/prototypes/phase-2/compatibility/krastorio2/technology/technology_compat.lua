local path = "prototypes/phase-2/compatibility/krastorio2/technology/"

require(path .. "modules")
require(path .. "equipment")
require(path .. "science")
require(path .. "matter")
require(path .. "military")
require(path .. "resources")
require(path .. "power")
require(path .. "logistics")