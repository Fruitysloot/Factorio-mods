local MATH_CEIL = math.ceil

local function sort_repair_tool (tool1, tool2)
	local tool1Prototype = game.item_prototypes[tool1]
	local tool2Prototype = game.item_prototypes[tool2]
	if tool1Prototype.infinite ~= tool2Prototype.infinite then
		return tool1Prototype.infinite
	end
	return tool1Prototype.speed > tool2Prototype.speed
end

-- pre 0.17.60 method
--[[
function index_tools()
	global.repair_tools = {}
	for _,prototype in pairs(game.item_prototypes) do
		if prototype.type == "repair-tool" then
			table.insert(global.repair_tools, prototype.name)
		end
	end
	table.sort(global.repair_tools, sort_repair_tool)
end
]]

local function index_tools()
	global.repair_tools = {}
	for _,prototype in pairs(game.get_filtered_item_prototypes({{filter="type", type="repair-tool"}})) do
		table.insert(global.repair_tools, prototype.name)
	end
	table.sort(global.repair_tools, sort_repair_tool)
end

-- Performs a repair on an item with a repair pack, simulating the given number of ticks
-- @param repairPack the repair pack to use in the repair
-- @param damagedItem the item to be repaired
-- @param time the number of ticks to simulate
-- @return whether a repair was actually carried out
local function repair_item(repairPack, damagedItem, time)
	local place_result = damagedItem.prototype.place_result
	if not place_result then return false end
	local maxHealth = place_result.max_health
	local currHealth = damagedItem.health * maxHealth
	local speed = repairPack.prototype.speed * place_result.repair_speed_modifier / damagedItem.count
	if speed == 0 then return false end -- if the entity can't actually be repaired, return
	local repairAmount = time -- change in durability to the repair pack. Actual repair amount is this * speed
	
	-- if performing the repair would heal it to above full health, clamp the repairs to full health
	if maxHealth - currHealth < repairAmount * speed then
		repairAmount  = (maxHealth-currHealth) / speed
	end
	repairAmount = MATH_CEIL(repairAmount) -- use up the entire durability point for verismilitude
	
	-- if the repairs require more durability than the tool has, clamp the repairs to the tool's durability
	if repairPack.durability < repairAmount and not repairPack.prototype.infinite then
		repairAmount = repairPack.durability
	end
	repairPack.drain_durability(repairAmount)
	damagedItem.health = (currHealth + repairAmount*speed) / maxHealth
	return true
end

-- Searches the inventory to find the first damaged item
-- @param inventory the Inventory to find the item in
-- @return the damaged ItemStack or nil if none are found
local function find_damaged_item(inventory)
	for i=1,#inventory do
		if inventory[i].valid_for_read then
			if inventory[i].health < 1.0 and inventory[i].prototype.place_result then
				return inventory[i]
			end
		end
	end
	return nil
end

-- Parses through the given player's inventory, finding a repair pack and a damaged item and repairing it.
-- @param player the player to check
-- @param infinite whether the item should be repaired to full health
-- @return whether or not repairs were performed
local function check_inventory_for_repairs(player, time)
	local performedRepairs = false
	local playerInventory = player.get_main_inventory()
	if playerInventory then -- spectators and ghosts don't have inventories
		local repairPack, damagedItem = nil, nil
		for _,itemName in pairs(global.repair_tools) do
			repairPack = playerInventory.find_item_stack(itemName)
			if repairPack then
				break
			end
		end
		
		if repairPack then
			damagedItem = find_damaged_item(playerInventory)
		end

		if repairPack and damagedItem then
			if repair_item(repairPack, damagedItem, time) then
				player.play_sound({path="repair-pack",position=player.position})
				performedRepairs = true
			end
		end
	end
	return performedRepairs
end

local function instant_repair(player)
	local inventory = player.get_main_inventory()
	if inventory then
		for i = 1,#inventory do
			local item_stack = inventory[i]
			if item_stack.valid_for_read then
				item_stack.health = 1
			end
		end
	end
end

local function register_player(pid)
	global.players[pid] = game.get_player(pid)
end

local function deregister_player(pid)
	global.players[pid] = nil
end

local function check_all_players(event)
	local interval = settings.global["inventory-repair-interval"].value
	if event.tick % interval == 0 then
		for pid,player in pairs(global.players) do
			if player.cheat_mode or player.controller_type == defines.controllers.editor then -- is the player in cheat mode or editor?
				instant_repair(player)
				deregister_player(pid)
			else
				-- attempt to repair an item and deregister the player if no repairs were performed
				if not check_inventory_for_repairs(player, interval) then
					deregister_player(pid)
				end
			end		
		end
	end
end

script.on_event({defines.events.on_player_joined_game,defines.events.on_player_main_inventory_changed}, function(event) register_player(event.player_index) end)
script.on_event({defines.events.on_player_left_game}, function (event) deregister_player(event.player_index) end)

--script.on_nth_tick(PERIOD, function(event) check_all_players(event) end)
script.on_init(function(event) 
	index_tools() 
	global.players = {}
end)

script.on_configuration_changed(function(event) 
	index_tools() 
	global.players = global.players or {}
end)

script.on_nth_tick(1, check_all_players)