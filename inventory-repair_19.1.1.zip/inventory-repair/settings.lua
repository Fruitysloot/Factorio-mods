
local settings = { 	

	-- runtime global
   {
		type = "int-setting",
		name = "inventory-repair-interval",
		setting_type = "runtime-global",
		default_value = 30,
		minimum_value = 1,
		order = "a[mode]",
	},
}

for _,setting in pairs(settings) do
	setting.localised_description = {"mod-setting-description." .. setting.name, setting.default_value, setting.minimum_value, setting.maximum_value}
end

data:extend(settings)