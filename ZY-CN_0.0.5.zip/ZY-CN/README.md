#  Space Exploration Patch

Compatibility patch for [Space Exploration](https://mods.factorio.com/mod/space-exploration)

Allows [        ](                                  ) to be built in space.